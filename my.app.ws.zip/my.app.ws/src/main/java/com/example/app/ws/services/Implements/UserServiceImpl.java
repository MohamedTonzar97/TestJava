package com.example.app.ws.services.Implements;

import java.util.ArrayList;
import java.util.Locale;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.app.ws.entities.UserEntity;
import com.example.app.ws.repositories.UserRepository;
import com.example.app.ws.services.UserService;
import com.example.app.ws.shared.Utils;
import com.example.app.ws.shared.dto.UserDto;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class UserServiceImpl implements UserService {
	
   @Autowired
   UserRepository userRepository;
   
   @Autowired
   BCryptPasswordEncoder bCryptPasswordEncoder;
   
   @Autowired
   Utils util;
   
	@Override
	public UserDto createUser(UserDto user) {
		// TODO Auto-generated method stub

		UserEntity checkUser = userRepository.findByEmail(user.getEmail());

		if (checkUser != null) throw new RuntimeException("User Already exists");
		if (user.getCountry()!= null &&!user.getCountry().toLowerCase(Locale.ROOT).equals("france")) throw new RuntimeException("User should be in france");

		if (user.getAge()!= null && user.getAge()<18 ) throw new RuntimeException("User should have more than 18 years old");

			UserEntity userEntity = new UserEntity();
			BeanUtils.copyProperties(user, userEntity);

			userEntity.setUserId(util.generateStringId(32));
			userEntity.setEncryptedPassword(bCryptPasswordEncoder.encode(user.getPassword()));


			UserEntity newUser = userRepository.save(userEntity);

			UserDto userDto = new UserDto();
			BeanUtils.copyProperties(newUser, userDto);


			return userDto;


	}


	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		// TODO Auto-generated method stub

		UserEntity userEntity = userRepository.findByEmail(email);
		if(userEntity == null ) throw new UsernameNotFoundException(email);
		
		return new User(userEntity.getEmail(),userEntity.getEncryptedPassword(),new ArrayList<>());
	}

}
